/**
 * Copyright (c) 2011, 2014, Jonathan Giles, Johan Vos, Hendrik Ebbers
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *     * Neither the name of DataFX, the website javafxdata.org, nor the
 * names of its contributors may be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL DataFX BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package io.datafx.core.concurrent;

import javafx.application.Platform;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;

/**
 * JavaFX 中并发问题的实用程序类
 *
 * @author Hendrik Ebbers
 */
public class ConcurrentUtils {

    private ConcurrentUtils() {
    }

    /**
     * <tt><tt> 在 JavaFX 应用程序线程上运行给定的可运行。该方法将阻塞，直到 <tt>Runnable<tt> 完全执行。
     * 应将 {@link ProcessChain} 用于并发任务和后台任务
     * 而不是使用此低级 API。
     *
     *
     * @param runnable 将在 JavaFX 应用程序线程上执行的可运行对象
     * @throws InterruptedException 如果 JavaFX 应用程序线程在等待时中断
     * @throws ExecutionException   如果 Runnable 的 run 方法的调用<tt><tt>引发异常
     */
    public static void runAndWait(Runnable runnable)
            throws InterruptedException, ExecutionException {
        FutureTask<Void> future = new FutureTask<>(runnable, null);
        Platform.runLater(future);
        future.get();
    }

    /**
     * <tt><tt> 在 JavaFX 应用程序线程上运行给定的可调用对象。该方法将一直阻塞，直到<tt>完全执行 Callable<tt>。
     * 将返回可调用对象的 call（） 方法的返回值
     * You should use the {@link ProcessChain} for concurrent tasks and background tasks
     * instead of using this low level API.
     *
     * @param callable 将在 JavaFX 应用程序线程上执行的可调用对象
     * @param <T>      可调用对象的返回类型
     * @return return value of the executed call() method of the <tt>Callable</tt><tt>可调用<tt>对象已执行的 call（） 方法的返回值
     * @throws InterruptedException 如果 JavaFX 应用程序线程在等待时中断
     * @throws ExecutionException   如果调用 Callable 的 run 方法引发<tt><tt>异常
     */
    public static <T> T runCallableAndWait(Callable<T> callable)
            throws InterruptedException, ExecutionException {
        FutureTask<T> future = new FutureTask<T>(callable);
        Platform.runLater(future);
        return future.get();
    }

    public static DataFxService<Void> createService(Runnable runnable) {
        return createService(new RunnableBasedDataFxTask(runnable));
    }

    public static <T> DataFxService<T> createService(Callable<T> callable) {
        return createService(new CallableBasedDataFxTask<T>(callable));
    }

    public static <T> DataFxService<T> createService(Task<T> task) {
        return new DataFxService<T>() {
            @Override
            protected Task<T> createTask() {
                return task;
            }
        };
    }

    public static <T> Worker<T> executeService(Executor executor, Service<T> service) {
        if (executor != null && executor instanceof ObservableExecutor) {
            return ((ObservableExecutor) executor).submit(service);
        } else {
            if (executor != null) {
                service.setExecutor(executor);
            }
            service.start();
            return service;
        }
    }

    public static <V> BooleanBinding isFinishedProperty(Worker<V> worker) {
        return worker.stateProperty().isEqualTo(Worker.State.CANCELLED).or(worker.stateProperty().isEqualTo(Worker.State.FAILED).or(worker.stateProperty().isEqualTo(Worker.State.SUCCEEDED)));
    }

    /**
一旦工作线程完成，将调用给定的使用者。工作线程的结果将传递给消费者。
     * @param worker the worker
     * @param consumer the consumer
     * @param <T> the resukt type of the worker
     */
    public static <T> void then(Worker<T> worker, Consumer<T> consumer) {
        ReadOnlyBooleanProperty doneProperty = createIsDoneProperty(worker);
        ChangeListener<Boolean> listener = (o, oldValue, newValue) -> {
            if (newValue) {
                consumer.accept(worker.getValue());
            }
        };
        doneProperty.addListener(listener);
    }

    /**
返回定义给定辅助角色的状态的属性。工作线程完成后，属性的值将设置为 true
     * @param worker the worker
     * @return the property
     */
    public static ReadOnlyBooleanProperty createIsDoneProperty(Worker<?> worker) {
        final BooleanProperty property = new SimpleBooleanProperty();
        Consumer<Worker.State> stateChecker = (s) -> {
            if (s.equals(Worker.State.CANCELLED) || s.equals(Worker.State.FAILED) || s.equals(Worker.State.SUCCEEDED)) {
                property.setValue(true);
            } else {
                property.setValue(false);
            }
        };
        worker.stateProperty().addListener((o, oldValue, newValue) -> stateChecker.accept(newValue));
        stateChecker.accept(worker.getState());
        return property;

    }

    /**
此方法将阻止，直到工作线程完成并返回工作线程的结果值。如果工作人员被取消，将引发异常。
     *
     * @param worker The worker
     * @param <T> result type of the worker
     * @return the result
     * @throws InterruptedException if the worker was canceled
     */
    public static <T> T waitFor(Worker<T> worker) throws InterruptedException {
        Lock lock = new ReentrantLock();
        Condition condition = lock.newCondition();
        lock.lock();
        try {
            ReadOnlyBooleanProperty doneProperty = createIsDoneProperty(worker);
            if (doneProperty.get()) {
                return worker.getValue();
            } else {
                doneProperty.addListener(e -> {
                    boolean locked = lock.tryLock();
                    if (locked) {
                        try {
                            condition.signal();
                        } finally {
                            lock.unlock();
                        }
                    } else {
                        throw new RuntimeException("Concurreny Error");
                    }
                });
                condition.await();
                return worker.getValue();
            }
        } finally {
            lock.unlock();
        }
    }
}
