/**
 * Copyright (c) 2011, 2014, Jonathan Giles, Johan Vos, Hendrik Ebbers
 * All rights reserved.
 * <p>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * * Neither the name of DataFX, the website javafxdata.org, nor the
 * names of its contributors may be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * <p>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL DataFX BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package io.datafx.core.concurrent;

import io.datafx.core.Assert;
import io.datafx.core.ExceptionHandler;
import javafx.beans.property.ListProperty;
import javafx.beans.property.ReadOnlyListProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.concurrent.Worker.State;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

/**
可以观察该任务的执行程序。所有当前正在运行和计划的任务都可以通过
 * <code>currentServices</code> 列表属性。每个后台任务 (
 * <code>Callable</code>,
 * <code>Runnable</code>, etc.) is wrapped in a
 * <code>Service</code>
 *
 * The
<code>ObservableExecutor<code> 可以用作默认的包装器
 * executor.
 *
 * @author Hendrik Ebbers
 *
 */
public class ObservableExecutor implements Executor {

    private static ObservableExecutor defaultInstance;

    private final Executor executor;

    private final ListProperty<Service<?>> currentServices;

    private final ExceptionHandler exceptionHandler;

    /**
创建一个新的可观察执行程序，该执行程序使用缓存的线程池来处理
     * all commited tasks.
     */
    public ObservableExecutor() {
        this(ThreadPoolExecutorFactory.getThreadPoolExecutor());
    }

    public ObservableExecutor(final Executor executor) {
        this(executor, ExceptionHandler.getDefaultInstance());
    }

    public ObservableExecutor(final ExceptionHandler exceptionHandler) {
        this(ThreadPoolExecutorFactory.getThreadPoolExecutor(), exceptionHandler);
    }

    /**
创建一个新的可观察执行器，该执行器使用给定的执行器来处理
     * all commited tasks.
     *
     * @param executor 包装的执行程序。它将用于处理所有任务
     * are commited to this executor.
     * @param exceptionHandler the exceptionhandler
     */
    public ObservableExecutor(final Executor executor, final ExceptionHandler exceptionHandler) {
        this.executor = Assert.requireNonNull(executor, "executor");
        this.exceptionHandler = Assert.requireNonNull(exceptionHandler, "exceptionHandler");
        currentServices = new SimpleListProperty<>(
                FXCollections.<Service<?>>observableArrayList());
        currentServices.addListener((ListChangeListener<? super Service<?>>) change -> {
            while (change.next()) {
                if (change.wasAdded()) {
                    List<? extends Service<?>> newServices = change
                            .getAddedSubList();
                    for (final Service<?> service : newServices) {
                        service.stateProperty().addListener(
                                new ChangeListener<State>() {
                                    @Override
                                    public void changed(
                                            ObservableValue<? extends State> observableValue,
                                            State oldSate, State newState) {
                                        if (newState != null
                                                && (newState
                                                .equals(State.CANCELLED)
                                                || newState
                                                .equals(State.SUCCEEDED) || newState
                                                .equals(State.FAILED))) {
                                            currentServices.remove(service);
                                        }
                                    }
                                });
                        State currentState = service.getState();
                        if (currentState != null
                                && (currentState.equals(State.CANCELLED)
                                || currentState
                                .equals(State.SUCCEEDED) || currentState
                                .equals(State.FAILED))) {
                            currentServices.remove(service);
                        }
                    }
                }
            }
        });
    }

    /**
返回包含所有当前计划和正在运行的任务的 ListProperty。
     *
     * @return a ListProperty that contains all currently scheduled and running
     * tasks.
     */
    public ReadOnlyListProperty<Service<?>> currentServicesProperty() {
        return currentServices;
    }

    /**
     *在将来的某个时间执行给定的服务。
     *
     * @param <T> The return type for the service
     * @param service the service.
     * @return a worker that can be used to check the state of the service and
     * receive the result of it.
     */
    public <T> Worker<T> submit(final Service<T> service) {
        Assert.requireNonNull(service, "service");
        service.setExecutor(executor);
        currentServices.add(service);
        if (exceptionHandler != null) {
            exceptionHandler.observeWorker(service);
        }
        service.start();
        return service;
    }

    /**
在将来的某个时间执行给定的任务。
     *
     * @param <T> the return type for the task
     * @param task the task.
     * @return a worker that can be used to check the state of the task and
     * receive the result of it.
     */
    public <T> Worker<T> submit(final Task<T> task) {
        return submit(ConcurrentUtils.createService(task));
    }

    /**
在将来的某个时间执行给定的可调用对象。
     *
     * @param <T> the return type for the worker
     * @param callable the callable. If a <code>DataFxCallable</code> is used
     * here a <code>TaskStateHandler</code> will be injected.
     * @return a worker that can be used to check the state of the callable and
     * receive the result of it.
     */
    public <T> Worker<T> submit(final Callable<T> callable) {
        return submit(ConcurrentUtils.createService(callable));
    }

    /**
在将来的某个时间执行给定的可运行对象。     *
     * @param runnable the runnable. If a <code>DataFxRunnable</code> is used
     * here a <code>TaskStateHandler</code> will be injected.
     * @return a worker that can be used to check the state of the runnable
     */
    public Worker<Void> submit(final Runnable runnable) {
        return submit(ConcurrentUtils.createService(runnable));
    }

    /**
在将来的某个时间执行给定的可运行对象。
     *
     * @param runnable the runnable. If a <code>DataFxRunnable</code> is used
     * here a <code>TaskStateHandler</code> will be injected.
     */
    public void execute(final Runnable runnable) {
        submit(runnable);
    }

    /**
     * Creates a new <tt>ProcessChain</tt> 使用此执行程序作为所有后台任务的执行程序。
     * @return a new <tt>ProcessChain</tt>
     *
     * @see ProcessChain
     */
    public ProcessChain<Void> createProcessChain() {
        return new ProcessChain<>(this);
    }

    /**
返回默认执行程序。这个使用内部缓存的线程池。
     * @return the default executor
     */
    public static synchronized ObservableExecutor getDefaultInstance() {
        if (defaultInstance == null) {
            defaultInstance = new ObservableExecutor();
        }
        return defaultInstance;
    }
}
