package io.datafx.controller.util;
import javafx.scene.Node;

/**
 * Created by hendrikebbers on 21.10.14.
 */
public class NullNode extends Node {

}
